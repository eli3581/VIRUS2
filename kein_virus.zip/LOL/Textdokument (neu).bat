@echo off
echo DU bist ein iddiot > nachricht.txt
start notepad nachricht.txt